<?php
defined('_JEXEC') or die;

$city = $params->get('city', 'Hanoi');
require JModuleHelper::getLayoutPath('mod_weatherinfo', $params->get('layout', 'default'));
