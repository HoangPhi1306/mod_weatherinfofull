<?php
defined('_JEXEC') or die;
?>

<form id="city-form">
  <label for="city-select">Chọn thành phố:</label>
  <select id="city-select">
  <option value="current">📍 Vị trí hiện tại</option>
  <option value="An Giang">An Giang</option>
<option value="Ba Ria">Bà Rịa - Vũng Tàu</option>
<option value="Bac Giang">Bắc Giang</option>
<option value="Bac Kan">Bắc Kạn</option>
<option value="Bac Lieu">Bạc Liêu</option>
<option value="Bac Ninh">Bắc Ninh</option>
<option value="Ben Tre">Bến Tre</option>
<option value="Binh Dinh">Bình Định</option>
<option value="Binh Duong">Bình Dương</option>
<option value="Binh Phuoc">Bình Phước</option>
<option value="Binh Thuan">Bình Thuận</option>
<option value="Ca Mau">Cà Mau</option>
<option value="Can Tho">Cần Thơ</option>
<option value="Cao Bang">Cao Bằng</option>
<option value="Da Nang">Đà Nẵng</option>
<option value="Dak Lak">Đắk Lắk</option>
<option value="Dak Nong">Đắk Nông</option>
<option value="Dien Bien">Điện Biên</option>
<option value="Dong Nai">Đồng Nai</option>
<option value="Dong Thap">Đồng Tháp</option>
<option value="Gia Lai">Gia Lai</option>
<option value="Ha Giang">Hà Giang</option>
<option value="Ha Nam">Hà Nam</option>
<option value="Ha Noi">Hà Nội</option>
<option value="Ha Tinh">Hà Tĩnh</option>
<option value="Hai Duong">Hải Dương</option>
<option value="Hai Phong">Hải Phòng</option>
<option value="Hau Giang">Hậu Giang</option>
<option value="Ho Chi Minh">TP. Hồ Chí Minh</option>
<option value="Hoa Binh">Hòa Bình</option>
<option value="Hung Yen">Hưng Yên</option>
<option value="Khanh Hoa">Khánh Hòa</option>
<option value="Kien Giang">Kiên Giang</option>
<option value="Kon Tum">Kon Tum</option>
<option value="Lai Chau">Lai Châu</option>
<option value="Lam Dong">Lâm Đồng</option>
<option value="Lang Son">Lạng Sơn</option>
<option value="Lao Cai">Lào Cai</option>
<option value="Long An">Long An</option>
<option value="Nam Dinh">Nam Định</option>
<option value="Nghe An">Nghệ An</option>
<option value="Ninh Binh">Ninh Bình</option>
<option value="Ninh Thuan">Ninh Thuận</option>
<option value="Phu Tho">Phú Thọ</option>
<option value="Phu Yen">Phú Yên</option>
<option value="Quang Binh">Quảng Bình</option>
<option value="Quang Nam">Quảng Nam</option>
<option value="Quang Ngai">Quảng Ngãi</option>
<option value="Quang Ninh">Quảng Ninh</option>
<option value="Quang Tri">Quảng Trị</option>
<option value="Soc Trang">Sóc Trăng</option>
<option value="Son La">Sơn La</option>
<option value="Tay Ninh">Tây Ninh</option>
<option value="Thai Binh">Thái Bình</option>
<option value="Thai Nguyen">Thái Nguyên</option>
<option value="Thanh Hoa">Thanh Hóa</option>
<option value="Thua Thien-Hue">Thừa Thiên Huế</option>
<option value="Tien Giang">Tiền Giang</option>
<option value="Tra Vinh">Trà Vinh</option>
<option value="Tuyen Quang">Tuyên Quang</option>
<option value="Vinh Long">Vĩnh Long</option>
<option value="Vinh Phuc">Vĩnh Phúc</option>
<option value="Yen Bai">Yên Bái</option>

  </select>
</form>

<div id="weather-data">Vui lòng chọn một thành phố để xem thời tiết.</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const select = document.getElementById('city-select');
  const output = document.getElementById('weather-data');
  const apiKey = 'f26089f8068a8a0b581d2e7e4609f5f0'; 

  function loadWeatherByCity(city) {
    output.innerHTML = `Đang tải thời tiết của ${city}...`;

    const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${apiKey}&units=metric&lang=vi`;

    fetch(url)
      .then(response => response.json())
      .then(data => {
        const temp = data.main.temp;
        const desc = data.weather[0].description;
        const name = data.name;
        output.innerHTML = `🌤️ Thời tiết tại <strong>${name}</strong>: ${temp}°C, ${desc}`;
      })
      .catch(error => {
        console.error(error);
        output.innerText = 'Không thể lấy thông tin thời tiết.';
      });
  }

  function loadWeatherByLocation() {
    if (!navigator.geolocation) {
      output.innerText = 'Trình duyệt không hỗ trợ định vị.';
      return;
    }

    output.innerHTML = 'Đang lấy vị trí...';

    navigator.geolocation.getCurrentPosition(function(position) {
      const lat = position.coords.latitude;
      const lon = position.coords.longitude;

      const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric&lang=vi`;

      fetch(url)
        .then(response => response.json())
        .then(data => {
          const temp = data.main.temp;
          const desc = data.weather[0].description;
          const name = data.name;
          output.innerHTML = `📍 Thời tiết tại <strong>${name}</strong>: ${temp}°C, ${desc}`;
        })
        .catch(error => {
          console.error(error);
          output.innerText = 'Không thể lấy thông tin thời tiết từ vị trí.';
        });
    }, function(error) {
      output.innerText = 'Không thể truy cập vị trí người dùng.';
    });
  }

  // Khi chọn thay đổi
  select.addEventListener('change', function() {
    const value = select.value;
    if (value === 'current') {
      loadWeatherByLocation();
    } else {
      loadWeatherByCity(value);
    }
  });

  // Gọi mặc định: load theo vị trí hoặc Hà Nội
  if (select.value === 'current') {
    loadWeatherByLocation();
  } else {
    loadWeatherByCity(select.value);
  }
});
</script>

