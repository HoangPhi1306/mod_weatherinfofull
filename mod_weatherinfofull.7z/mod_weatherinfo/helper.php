<?php
defined('_JEXEC') or die;

class ModWeatherInfoHelper
{
    public static function getWeather($params)
    {
        $city = $params->get('city', 'Hanoi');
        $apiKey = $params->get('apikey');

        // Kiểm tra xem có API key chưa
        if (empty($apiKey)) {
            return ['error' => 'Chưa cấu hình API key'];
        }

        // Gọi API OpenWeatherMap
        $url = "https://api.openweathermap.org/data/2.5/weather?q={$city}&appid={$apiKey}&units=metric&lang=vi";

        // Lấy nội dung JSON từ API
        $response = file_get_contents($url);

        if ($response === false) {
            return ['error' => 'Không lấy được dữ liệu từ API'];
        }

        // Chuyển đổi JSON thành mảng PHP
        $data = json_decode($response, true);

        // Trả dữ liệu về để hiển thị
        return $data;
    }
}
