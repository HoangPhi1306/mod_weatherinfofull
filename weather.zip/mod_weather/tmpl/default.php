<?php
defined('_JEXEC') or die;

$apikey = $params->get('apikey');
$units = $params->get('units', 'metric');
$unitSymbol = $units == 'imperial' ? '°F' : '°C';
?>

<style>
  .weather-wrapper {
    max-width: 860px;
    margin: 20px auto;
    padding: 24px;
    border-radius: 20px;
    backdrop-filter: blur(8px);
    background: rgba(31, 41, 55, 0.85);
    color: #ffffff;
    box-shadow: 0 12px 24px rgba(0, 0, 0, 0.25);
    font-family: 'Segoe UI', sans-serif;
  }

  .weather-inputs {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 10px;
    margin-bottom: 15px;
  }

  .weather-inputs input {
    padding: 10px;
    border-radius: 12px;
    border: 1px solid #ccc;
    width: 240px;
    font-size: 16px;
  }

  .weather-inputs button {
    padding: 10px 16px;
    border: none;
    border-radius: 12px;
    font-size: 15px;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }

  .btn-primary {
    background-color: #0d6efd;
    color: white;
  }

  .btn-primary:hover {
    background-color: #084298;
  }

  .btn-location {
    background-color: #28a745;
    color: white;
  }

  .btn-location:hover {
    background-color: #1e7e34;
  }

  .forecast-cards {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 14px;
    margin-top: 20px;
  }

  .forecast-card {
    background: rgba(255, 255, 255, 0.9);
    color: #222;
    border-radius: 16px;
    padding: 16px;
    width: 120px;
    text-align: center;
    box-shadow: 0 6px 12px rgba(0,0,0,0.15);
    transition: transform 0.2s ease;
  }

  .forecast-card:hover {
    transform: translateY(-5px);
  }

  .forecast-card img {
    width: 60px;
    height: 60px;
  }

  @media (max-width: 600px) {
    .forecast-card {
      width: 100%;
    }
    .weather-inputs {
      flex-direction: column;
      align-items: center;
    }
    .weather-inputs input {
      width: 100%;
    }
  }
</style>

<div class="weather-wrapper">
   <div id="weather-container" style="margin-bottom: 24px;">Nhập tên thành phố hoặc dùng vị trí hiện tại để xem dự báo.</div>

  <div class="weather-inputs">
    <input type="text" id="city-input" placeholder="🔍 Nhập tên thành phố (Hanoi, Tokyo, Paris)">
    <button id="city-submit" class="btn-primary">Xem thời tiết</button>
    <button id="use-geo" class="btn-location">📍 Dùng vị trí hiện tại</button>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
  const apiKey = "<?php echo htmlspecialchars($apikey, ENT_QUOTES, 'UTF-8'); ?>";
  const units = "<?php echo $units; ?>";
  const unitSymbol = "<?php echo $unitSymbol; ?>";
  const container = document.getElementById("weather-container");
  const cityInput = document.getElementById("city-input");
  const citySubmit = document.getElementById("city-submit");
  const useGeoBtn = document.getElementById("use-geo");

  function renderLoading(message = '⏳ Đang tải dữ liệu thời tiết...') {
    container.innerHTML = `<p>${message}</p>`;
  }

  function formatDate(dt) {
    const date = new Date(dt * 1000);
    return date.toLocaleDateString('vi-VN', { weekday: 'long', day: '2-digit', month: '2-digit' });
  }

  async function fetchWeather(url) {
    renderLoading();
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error("Lỗi kết nối API");
      const data = await res.json();
      if (data.cod === '200') {
        renderForecast(data);
      } else {
        container.innerHTML = `<p>⚠️ Không tìm thấy dữ liệu thời tiết: ${data.message}</p>`;
      }
    } catch (err) {
      container.innerHTML = `<p>❌ Lỗi khi tải dữ liệu thời tiết: ${err.message}</p>`;
    }
  }

  function renderForecast(data) {
    const city = data.city.name;
    let forecastHTML = `<h3 style="margin-bottom: 10px;">🌤️ Dự báo 5 ngày tại <strong>${city}</strong></h3><div class="forecast-cards">`;
    data.list.forEach((item, index) => {
      if (index % 8 === 0) {
        const date = formatDate(item.dt);
        const tempMin = Math.round(item.main.temp_min);
        const tempMax = Math.round(item.main.temp_max);
        const desc = item.weather[0].description;
        const icon = item.weather[0].icon;
        forecastHTML += `
          <div class="forecast-card">
            <div style="font-weight: bold; font-size: 14px;">${date}</div>
            <img src="https://openweathermap.org/img/wn/${icon}@2x.png" alt="${desc}">
            <div style="font-size: 13px;">${desc.charAt(0).toUpperCase() + desc.slice(1)}</div>
            <div style="margin-top: 4px; font-weight: bold; color: #0d6efd;">${tempMin}${unitSymbol} - ${tempMax}${unitSymbol}</div>
          </div>
        `;
      }
    });
    forecastHTML += '</div>';
    container.innerHTML = forecastHTML;
    cityInput.value = '';
  }

  citySubmit.addEventListener('click', () => {
    const city = cityInput.value.trim();
    if (city) {
      const url = `https://api.openweathermap.org/data/2.5/forecast?q=${encodeURIComponent(city)}&appid=${apiKey}&units=${units}&lang=vi`;
      fetchWeather(url);
    } else {
      alert("⚠️ Vui lòng nhập tên thành phố.");
    }
  });

  useGeoBtn.addEventListener('click', () => {
    if (navigator.geolocation) {
      renderLoading("📍 Đang xác định vị trí...");
      navigator.geolocation.getCurrentPosition(
        pos => {
          const lat = pos.coords.latitude;
          const lon = pos.coords.longitude;
          const url = `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${apiKey}&units=${units}&lang=vi`;
          fetchWeather(url);
        },
        err => {
          container.innerHTML = `<p>❌ Không thể truy cập vị trí: ${err.message}</p>`;
        },
        { timeout: 10000, maximumAge: 60000 }
      );
    } else {
      container.innerHTML = '<p>⚠️ Trình duyệt không hỗ trợ định vị.</p>';
    }
  });
});
</script>
