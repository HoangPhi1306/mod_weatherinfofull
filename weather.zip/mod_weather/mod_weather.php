<?php
defined('_JEXEC') or die;
require JModuleHelper::getLayoutPath('mod_weather', $params->get('layout', 'default'));
